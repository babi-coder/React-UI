## Run the application

* `npm install` to install all dependencies.
* `npm start` to run the application.
