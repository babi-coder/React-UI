## Run the application

- `npm install` to install all dependencies.
- `npm start` to run the application.
- `nodemon start app.js` to run the application in auto-restart after changes mode.
